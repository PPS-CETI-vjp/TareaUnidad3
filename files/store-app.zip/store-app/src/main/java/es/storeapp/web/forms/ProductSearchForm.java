package es.storeapp.web.forms;

public class ProductSearchForm {
    
    private String category;

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
    
}
